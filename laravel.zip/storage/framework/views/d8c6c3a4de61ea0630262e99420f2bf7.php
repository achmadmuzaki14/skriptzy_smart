<?php
if (auth()->user()->role == 'super_admin') {
    $community = 'all';
} else if(auth()->user()->role == 'pembimbing'){
    $community = auth()->user()->community->name;
} else{
    $community = 'user';
}
?>
<aside class="sidenav navbar navbar-vertical navbar-expand-xs border-0 bg-slate-900 fixed-start " id="sidenav-main">
    <div class="sidenav-header">
        <i class="fas fa-times p-3 cursor-pointer text-secondary opacity-5 position-absolute end-0 top-0 d-none d-xl-none"
            aria-hidden="true" id="iconSidenav"></i>
        <a class="navbar-brand d-flex align-items-center m-0"
            href=" https://demos.creative-tim.com/corporate-ui-dashboard/pages/dashboard.html " target="_blank">
            <span class="font-weight-bold text-lg">SIPMATEKA</span>
        </a>
    </div>
    <div class="collapse navbar-collapse px-4  w-auto " id="sidenav-collapse-main">
        <ul class="navbar-nav">
            
            <li class="nav-item">
                <a class="nav-link <?php echo e(is_current_route('result') ? 'active' : ''); ?>" href="<?php echo e(route('result.index')); ?>">
                    <div
                        class="icon icon-shape icon-sm px-0 text-center d-flex align-items-center justify-content-center">
                        <svg width="30px" height="30px" viewBox="0 0 48 48" version="1.1"
                            xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                            <title>Dashboard</title>
                            <g id="result" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                <g id="template" transform="translate(12.000000, 12.000000)" fill="#FFFFFF"
                                    fill-rule="nonzero">
                                    <path class="color-foreground"
                                        d="M0,1.71428571 C0,0.76752 0.76752,0 1.71428571,0 L22.2857143,0 C23.2325143,0 24,0.76752 24,1.71428571 L24,5.14285714 C24,6.08962286 23.2325143,6.85714286 22.2857143,6.85714286 L1.71428571,6.85714286 C0.76752,6.85714286 0,6.08962286 0,5.14285714 L0,1.71428571 Z"
                                        id="Path"></path>
                                    <path class="color-background"
                                        d="M0,12 C0,11.0532171 0.76752,10.2857143 1.71428571,10.2857143 L12,10.2857143 C12.9468,10.2857143 13.7142857,11.0532171 13.7142857,12 L13.7142857,22.2857143 C13.7142857,23.2325143 12.9468,24 12,24 L1.71428571,24 C0.76752,24 0,23.2325143 0,22.2857143 L0,12 Z"
                                        id="Path"></path>
                                    <path class="color-background"
                                        d="M18.8571429,10.2857143 C17.9103429,10.2857143 17.1428571,11.0532171 17.1428571,12 L17.1428571,22.2857143 C17.1428571,23.2325143 17.9103429,24 18.8571429,24 L22.2857143,24 C23.2325143,24 24,23.2325143 24,22.2857143 L24,12 C24,11.0532171 23.2325143,10.2857143 22.2857143,10.2857143 L18.8571429,10.2857143 Z"
                                        id="Path"></path>
                                </g>
                            </g>
                        </svg>
                    </div>
                    <span class="nav-link-text ms-1">Dashboard</span>
                </a>
            </li>
            <!-- Start Penilaian -->
            <li class="nav-item mt-2">
                <div class="d-flex align-items-center nav-link">
                    <i class="fa-solid fa-star ms-2" style="color: #ffffff;"></i>
                    <span class="font-weight-normal text-md ms-2">Penilaian</span>
                </div>
            </li>
            <!-- need penyesuaian -->
            <li class="nav-item border-start my-0 pt-2">
                
                    <a class="nav-link position-relative ms-0 ps-2 py-2 <?php echo e(is_current_route('scoring.index', ['communityName' => $community]) ? 'active' : ''); ?>"
                        href="<?php echo e(route('scoring.index', ['communityName' => $community])); ?>">
                        <span class="nav-link-text ms-1">Index Penilaian</span>
                    </a>
                
                    
                
            </li>
            <!-- need penyesuaian -->
            
            
            <!-- End Penilaian -->
            <!-- Start Community -->
            <li class="nav-item mt-2">
                <div class="d-flex align-items-center nav-link">
                    <i class="fa-solid fa-users ms-2"></i>
                    <span class="font-weight-normal text-md ms-2">Community</span>
                </div>
            </li>
            <li class="nav-item border-start my-0 pt-2">
                <a class="nav-link position-relative ms-0 ps-2 py-2 <?php echo e(is_current_route('community.index') ? 'active' : ''); ?>"
                    href="<?php echo e(route('community.index')); ?>">
                    <span class="nav-link-text ms-1">Index Community</span>
                </a>
            </li>
            <?php if(auth()->user()->role == 'super_admin' || auth()->user()->role == 'pembimbing'): ?>
            <li class="nav-item border-start my-0 pt-2">
                <a class="nav-link position-relative ms-0 ps-2 py-2 <?php echo e(is_current_route('community.create') ? 'active' : ''); ?>"
                    href="<?php echo e(route('community.create')); ?>">
                    <span class="nav-link-text ms-1">Add Community</span>
                </a>
            </li>
            <?php endif; ?>
            <!-- End Community -->
            <!-- Start Kriteria -->
            <li class="nav-item mt-2">
                <div class="d-flex align-items-center nav-link">
                    
                    <i class="fa-solid fa-list-ol ms-2"></i>
                    <span class="font-weight-normal text-md ms-2">Kriteria</span>
                </div>
            </li>
            <li class="nav-item border-start my-0 pt-2">
                <a class="nav-link position-relative ms-0 ps-2 py-2 <?php echo e(is_current_route('criteria.weboender.index', ['communityName' => $community]) ? 'active' : ''); ?>"
                    href="<?php echo e(route('criteria.weboender.index', ['communityName' => $community])); ?>">
                    <span class="nav-link-text ms-1">Index Kriteria</span>
                </a>
            </li>
            <!-- need penyesuaian -->
            <?php if(auth()->user()->role == 'pembimbing' || auth()->user()->role == 'super_admin'): ?>
                <li class="nav-item border-start my-0 pt-2">
                    <a class="nav-link position-relative ms-0 ps-2 py-2 <?php echo e(is_current_route('criteria.weboender.create') ? 'active' : ''); ?>"
                        href="<?php echo e(route('criteria.weboender.create')); ?>">
                        <span class="nav-link-text ms-1">Add Kriteria</span>
                    </a>
                </li>
            <?php endif; ?>
            <!-- End Kriteria -->
            <!-- Start Alternative -->
            <li class="nav-item mt-2">
                <div class="d-flex align-items-center nav-link">
                    <i class="fa-solid fa-arrow-up-z-a ms-2 fa-xl"></i>
                    <span class="font-weight-normal text-md ms-2">Alternatif</span>
                </div>
            </li>

                <li class="nav-item border-start my-0 pt-2">
                    <a class="nav-link position-relative ms-0 ps-2 py-2 <?php echo e(is_current_route('alternative.weboender.index') ? 'active' : ''); ?>"
                        href="<?php echo e(route('alternative.weboender.index')); ?>">
                        <span class="nav-link-text ms-1">Index Alternatif</span>
                    </a>
                </li>
            <!-- need penyesuaian -->
            <?php if(auth()->user()->role == 'pembimbing' || auth()->user()->role == 'super_admin'): ?>
                <li class="nav-item border-start my-0 pt-2">
                    <a class="nav-link position-relative ms-0 ps-2 py-2 <?php echo e(is_current_route('alternative.weboender.create') ? 'active' : ''); ?>"
                        href="<?php echo e(route('alternative.weboender.create')); ?>">
                        <span class="nav-link-text ms-1">Add Alternatif</span>
                    </a>
                </li>
            <?php endif; ?>
            <!-- End Alternative -->
            
            
            
            
        </ul>
    </div>
    <div class="sidenav-footer mx-4 ">
        <form method="POST" action="<?php echo e(route('logout')); ?>">
            <?php echo csrf_field(); ?>
            <a class="btn bg-gradient-primary inline-block px-5 py-2 mx-auto text-xs align-middle transition-all ease-in border-0 rounded-lg select-none" style="width:200px" href="login" onclick="event.preventDefault();
        this.closest('form').submit();">
                <button class="btn btn-sm text-white mb-0 no-border-on-hover" type="submit">Log out</button>
            </a>
        </form>
        
        <div class="card border-radius-md" id="sidenavCard">
            <div class="card-body  text-start  p-3 w-100">
                <div class="mb-3">
                    <i class="fa-brands fa-whatsapp text-primary fa-lg"></i>
                    
                    
                </div>
                <div class="docs-info">
                    <h6 class="font-weight-bold up mb-2">Need help?</h6>
                    <p class="text-sm font-weight-normal">Please contact admin</p>
                    <a href="https://wa.me/+6285755990290"
                        target="_blank" class="font-weight-bold text-sm mb-0 icon-move-right mt-auto w-100 mb-0">
                        Contact Person
                        <i class="fas fa-arrow-right-long text-sm ms-1" aria-hidden="true"></i>
                    </a>
                </div>
            </div>
        </div>
    </div>
</aside>
<style>
    .no-border-on-hover:hover {
        border: none !important;
    }
</style>
<?php /**PATH /Users/zakismac/Documents/kuliah/Skripsi/dev/resources/views/components/app/sidebar.blade.php ENDPATH**/ ?>