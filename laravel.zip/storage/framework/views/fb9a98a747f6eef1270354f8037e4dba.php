<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <main class="main-content position-relative max-height-vh-100 h-100 border-radius-lg ">
        <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app.navbar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app.navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
        <div class="px-5 py-4 container-fluid">
            <div class="mt-4 row">
                <div class="col-12">
                    
                    <div class="card">
                        <div class="pb-0 card-header">
                            <div class="row">
                                <div class="col-6">
                                    <h5 class="">Scoring Management</h5>
                                    <p class="mb-0 text-sm">
                                        Here you can manage score.
                                    </p>
                                </div>
                                <div class="col-6 text-end">
                                    
                                    <?php if(auth()->user()->role == 'super_admin' || auth()->user()->role == 'pembimbing'): ?>
                                    <button type="button" class="btn btn-dark" data-bs-toggle="modal" data-bs-target="#alternativeModal">
                                        Tambah Penilaian
                                      </button>
                                      <?php endif; ?>
                                    <!-- modal select alternative -->
                                        <div class="modal fade" id="alternativeModal" tabindex="-1" role="dialog"
                                        aria-labelledby="alternativeModalLabel" aria-hidden="true">
                                            <div class="modal-dialog" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                <h5 class="modal-title" id="alternativeModalLabel">Pilih Alternatif</h5>
                                                <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                  </button>
                                                </div>
                                                <div class="modal-body">
                                                <select class="form-control" id="alternativeSelect" name="alternative_id">
                                                    <option value="">Pilih Alternatif</option>
                                                    <?php $__currentLoopData = $alternatives; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alternative_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($alternative_data->id); ?>"><?php echo e($alternative_data->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                                                    <button type="button" class="btn btn-primary" id="selanjutnyaBtn">Selanjutnya</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- modal select alternative -->
                                </div>
                            </div>
                        </div>
                        <div class="row justify-content-center">
                            <div class="">
                                <?php if(session('success')): ?>
                                    <div class="alert alert-success" role="alert" id="alert">
                                        <?php echo e(session('success')); ?>

                                    </div>
                                <?php endif; ?>
                                <?php if(session('error')): ?>
                                    <div class="alert alert-danger" role="alert" id="alert">
                                        <?php echo e(session('error')); ?>

                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="table-responsive p-3">
                            <table class="table text-secondary text-center" id="tables">
                                <thead>
                                    <tr>
                                        <th
                                            class="text-center text-uppercase font-weight-bold bg-transparent border-bottom text-secondary">
                                            ID</th>
                                        <th
                                            class="text-center text-uppercase font-weight-bold bg-transparent border-bottom text-secondary">
                                            Nama Penilai</th>
                                        <th
                                            class="text-center text-uppercase font-weight-bold bg-transparent border-bottom text-secondary">
                                            Nama Alternatif</th>
                                        <th
                                            class="text-center text-uppercase font-weight-bold bg-transparent border-bottom text-secondary">
                                            Score</th>
                                        <?php if(auth()->user()->role == 'super_admin' || auth()->user()->role == 'pembimbing'): ?>
                                            <th
                                                class="text-center text-uppercase font-weight-bold bg-transparent border-bottom text-secondary">
                                                Action</th>
                                        <?php endif; ?>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $alternative_values_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alternative_values): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <tr>
                                        <td class="text-center"><?php echo e($loop->iteration); ?></td>
                                        <td class="text-start"><?php echo e($alternative_values->user->name); ?></td>
                                        <td><?php echo e($alternative_values->alternative->name); ?></td>
                                        <td class="text-center"><?php echo e($alternative_values->value); ?></td>
                                        <?php if(auth()->user()->role == 'super_admin' || auth()->user()->role == 'pembimbing'): ?>
                                            <td>
                                                <a href="<?php echo e(route('scoring.edit', $alternative_values->id)); ?>" class="btn btn-warning btn-sm">
                                                    <i class="fas fa-pen"></i> Edit
                                                </a>
                                                <a href="<?php echo e(route('alternativeValue.destroy', $alternative_values->id)); ?>" class="btn btn-danger btn-sm"
                                                    data-confirm-delete="true"><i class="fas fa-trash fa-sm mx-1"></i>Delete</a>
                                            </td>
                                        <?php endif; ?>
                                      </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app.footer','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app.footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
    </main>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<script>
    $(document).ready(function() {
      $("#selanjutnyaBtn").click(function() {
        let alternativeId = $("#alternativeSelect").val();
        if (alternativeId) {
          $.ajax({
            url: "<?php echo e(route('alternative.get-by-community')); ?>",
            type: "POST",
            data: {
              _token: "<?php echo e(csrf_token()); ?>",
              alternative_id: alternativeId
            },
            success: function(response) {
              window.location.href = "<?php echo e(route('scoring.create')); ?>" + "?alternative=" +
                alternativeId
            },
            error: function(xhr, status, error) {
              console.error(xhr.responseText);
            }
          })
        }
      });
    });
  </script>

<script src="https://cdn.datatables.net/2.0.7/js/dataTables.js"></script>
<script>
    $(document).ready(function() {
        $('#tables').DataTable({
            searching: true, // Aktifkan fitur pencarian
            scrollX: false
        });
    });
</script>


<?php /**PATH /Users/zakismac/Documents/kuliah/Skripsi/dev/resources/views/scoring/index.blade.php ENDPATH**/ ?>