<footer class="footer p-5">
    <div class="row align-items-center justify-content-lg-between ">
        <div class="col-lg-6 mb-lg-0 mb-4">
            <div class="copyright text-center text-m text-muted text-lg-start">
                Copyright
                ©
                <script>
                    document.write(new Date().getFullYear())
                </script>
                made with <i class="fa fa-heart"></i> by
                <a href="https://www.creative-tim.com" class="text-secondary text-bold" target="_blank">Achmad Muzaki G</a>
                
            </div>
        </div>
        <div class="col-lg-6">
            
        </div>
    </div>
</footer>
<?php /**PATH /Users/zakismac/Documents/kuliah/Skripsi/dev/resources/views/components/app/footer.blade.php ENDPATH**/ ?>